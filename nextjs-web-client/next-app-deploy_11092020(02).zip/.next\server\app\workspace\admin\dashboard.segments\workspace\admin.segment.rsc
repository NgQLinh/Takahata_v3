1:"$Sreact.fragment"
2:I[549919,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/19rivyb3ahph9.js"],"default"]
3:I[339756,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
4:I[837457,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
:HL["/_next/static/chunks/1j3wya62tsrml.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1j3wya62tsrml.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/19rivyb3ahph9.js","async":true}]],["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"By6M6Bn_2cGvgITRkwtuT"}
