1:"$Sreact.fragment"
2:I[474205,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/19rivyb3ahph9.js","/_next/static/chunks/425-6j4wmon9p.js","/_next/static/chunks/0kjl5cgc-m731.js","/_next/static/chunks/3vhbmpumilg-x.js","/_next/static/chunks/3s26b_xdit355.js"],"DashboardPage"]
3:I[897367,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/39tt6vqktks7w.css","style"]
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gray-100 p-2","children":["$","$L2",null,{}]}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/39tt6vqktks7w.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/425-6j4wmon9p.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0kjl5cgc-m731.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/3vhbmpumilg-x.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/3s26b_xdit355.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"By6M6Bn_2cGvgITRkwtuT"}
5:null
