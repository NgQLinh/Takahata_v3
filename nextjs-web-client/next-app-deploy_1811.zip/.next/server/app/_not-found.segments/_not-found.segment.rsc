1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
3:I[837457,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"XZ_fqs-BeIsSt8OaCUl5e"}
