1:"$Sreact.fragment"
2:I[474205,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/19rivyb3ahph9.js","/_next/static/chunks/2p67ftp4s52lp.js","/_next/static/chunks/38jjabubxz2do.js","/_next/static/chunks/34pt5id7s7y7d.js","/_next/static/chunks/3s26b_xdit355.js"],"DashboardPage"]
3:I[897367,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/1_1j0k4-gj62w.css","style"]
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gray-100 p-2","children":["$","$L2",null,{}]}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1_1j0k4-gj62w.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2p67ftp4s52lp.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/38jjabubxz2do.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/34pt5id7s7y7d.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/3s26b_xdit355.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"YlWXEd6jVBXbfR5f26xmk"}
5:null
