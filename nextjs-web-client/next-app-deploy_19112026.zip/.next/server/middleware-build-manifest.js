globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/YlWXEd6jVBXbfR5f26xmk/_buildManifest.js",
    "static/YlWXEd6jVBXbfR5f26xmk/_ssgManifest.js",
    "static/YlWXEd6jVBXbfR5f26xmk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/046rkacd53sxw.js",
    "static/chunks/3u1yqrswiftwe.js",
    "static/chunks/2ejk_26znfoeu.js",
    "static/chunks/06j3juy1u5a-6.js",
    "static/chunks/2-53m74dqkhnw.js",
    "static/chunks/turbopack-1145z3tbgoqu-.js"
  ]
};
